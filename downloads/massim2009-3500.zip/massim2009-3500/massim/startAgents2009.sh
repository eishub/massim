#! /bin/sh
echo "Please specifiy the hostname of the server:"
read HOST

echo "Please set the number of agents:"
read NUMBER_AGENT

i=1
for i in $(seq $NUMBER_AGENT); do
	java -jar DemoAgent.jar -username $i -password 1 -host $HOST -logpath AgentsLog &  
	sleep 1
done


